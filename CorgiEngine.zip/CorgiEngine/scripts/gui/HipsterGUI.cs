﻿using UnityEngine;
using System.Collections;

public class HipsterGUI : MonoBehaviour {

	// Use this for initialization
	void Start ()
    {
        GUIManager.Instance.SetAvatarActive(false);
    }
}
