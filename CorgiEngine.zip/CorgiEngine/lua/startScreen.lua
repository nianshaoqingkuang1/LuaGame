local startScreen = {}
local pausebtn

function startScreen.Start()
	local buttonA = GameObject.Find("buttonA")
	print(buttonA)

	local boxcollider = buttonA:AddComponent(LuaHelper.GetClsType("BoxColliderCheck"))
	boxcollider.onEnterCollider:AddListener(function()
		startScreen.GotoNextLevel()
	end)

	pausebtn = GameObject.Find("UICamera/Canvas/PauseButton")
	print(pausebtn)
	EventTriggerListener.Get(pausebtn).onClick = {"+=",startScreen.onClick,}

	local buttons = GameObject.Find("UICamera/Canvas/Buttons").transform
	EventTriggerListener.Get(buttons:Find("JumpButton").gameObject).onClick = {"+=",startScreen.onClick,}
	EventTriggerListener.Get(buttons:Find("RunButton").gameObject).onClick = {"+=",startScreen.onClick,}
	EventTriggerListener.Get(buttons:Find("JetpackButton").gameObject).onClick = {"+=",startScreen.onClick,}
	EventTriggerListener.Get(buttons:Find("DashButton").gameObject).onClick = {"+=",startScreen.onClick,}
	EventTriggerListener.Get(buttons:Find("FireButton").gameObject).onClick = {"+=",startScreen.onClick,}

	local arrows = GameObject.Find("UICamera/Canvas/Arrows").transform
	EventTriggerListener.Get(arrows:Find("ArrowLeft").gameObject).onClick = {"+=",startScreen.onClick,}
	EventTriggerListener.Get(arrows:Find("ArrowRight").gameObject).onClick = {"+=",startScreen.onClick,}
	EventTriggerListener.Get(arrows:Find("ArrowDown").gameObject).onClick = {"+=",startScreen.onClick,}
	EventTriggerListener.Get(arrows:Find("ArrowUp").gameObject).onClick = {"+=",startScreen.onClick,}

	local PauseSplash = GameObject.Find("UICamera/Canvas/PauseSplash").transform
	EventTriggerListener.Get(PauseSplash:Find("BackToLevelSelectionButton").gameObject).onClick = {"+=",startScreen.onClick,}
	EventTriggerListener.Get(PauseSplash:Find("RestartLevelButton").gameObject).onClick = {"+=",startScreen.onClick,}
	EventTriggerListener.Get(PauseSplash:Find("ResumeButton").gameObject).onClick = {"+=",startScreen.onClick,}

	local Characters = GameObject.Find("Characters")
	local c1 = Characters.transform:Find("spine-space-corgi").gameObject
	local boxcollider = c1:AddComponent(LuaHelper.GetClsType("BoxColliderCheck"))
	boxcollider.onEnterCollider:AddListener(function()
		print("222222222222222222222222")
	end)
end

function startScreen.GotoNextLevel()
	GameUtil.AnsyLoadLevel("LuaLevelSelection",function(success)
		print("LoadLevel:LuaLevelSelection",success)

		local luaFileObj= GameObject("LuaFile")
		local scriptFile = luaFileObj:AddComponent(LuaHelper.GetClsType("LuaScriptFile"))
		warn("scriptFile",scriptFile)
		scriptFile.scriptFileName = "levelSelection"
	end)
end

function startScreen.ShowPauseSplash(show)
	local pause = GameObject.Find("UICamera/Canvas/PauseSplash")
	pause:SetActive(show)
end

function startScreen.onClick(go)
	print(go.name)
	if go.name == "PauseButton" then
		startScreen.ShowPauseSplash(true)
	elseif go.name == "ResumeButton" then
		startScreen.ShowPauseSplash(false)
	end
end

function startScreen.Update()
end

function startScreen.OnDestroy()
end

return startScreen
