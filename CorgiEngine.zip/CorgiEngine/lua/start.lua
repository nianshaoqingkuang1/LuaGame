
-- GameUtil.SendRequest("http://www.baidu.com","hello",3,true,function(req,resp)
-- 	if resp.IsSuccess then
-- 		local str=resp.DataAsText
-- 		print(str)
-- 	else
-- 		print("error")
-- 	end
-- end)

-- GameUtil.DownLoad("http://www.baidu.com",
-- 	"E:/UnityWorks/t.txt",true,true,nil,function(a,b,c)
-- 		print("progress:",a,b,c)
-- 	end,function(req,resp)
-- 		print(req,resp)
-- 		if not req.Exception then
-- 			if resp.IsSuccess then
-- 				print("download completed.. now unzip")
-- 				--tmpfile=this.AssetRoot.."/tmp.zip"
-- 			end
-- 	    else
-- 	    	print("DownLoad file err",resp)
-- 		end
-- 	end)
import "UnityEngine"
GameObject = UnityEngine.GameObject
Vector2 = UnityEngine.Vector2
Vector3 = UnityEngine.Vector3
Quaternion = UnityEngine.Quaternion

GameUtil.AnsyLoadLevel("LuaStartScreen",function(success)
	print("LoadLevel:LuaStartScreen",success)

	local luaFileObj= GameObject("LuaFile")
	local scriptFile = luaFileObj:AddComponent(LuaHelper.GetClsType("LuaScriptFile"))
	warn("scriptFile",scriptFile)
	scriptFile.scriptFileName = "startScreen"
end)
