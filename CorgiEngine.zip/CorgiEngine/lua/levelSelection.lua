
local levelSelection = {}


function levelSelection.Start()
	print("levelSelection",levelSelection.this)
end

function levelSelection.onClick(go)
	print(go.name)

end

return levelSelection
