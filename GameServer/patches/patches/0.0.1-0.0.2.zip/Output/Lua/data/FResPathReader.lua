local respath_list = dofile "configs.respath_list"

--此处可以做一下唯一检查

ResPathReader = respath_list